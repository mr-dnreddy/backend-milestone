package com.dn.booking.service;

import java.util.List;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.slf4j.Logger;
import com.dn.booking.entity.Booking;
import com.dn.booking.entity.Payment;
import com.dn.booking.entity.Property;
import com.dn.booking.repository.BookingRepository;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class BookingService {
    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private RestTemplate restTemplate;
    

    private static final Logger logger = LoggerFactory.getLogger(BookingService.class);
    
 // Circuit Breaker for Property Service
    
    public Property getPropertyById(int propertyId) {
    	System.out.println("testing inside property-circuit breaker");
        String url = "http://property-service/property/" + propertyId;
        try {
            return restTemplate.getForObject(url, Property.class);
        } catch (HttpServerErrorException.ServiceUnavailable ex) {
            logger.error("Property Service is currently unavailable: {}", ex.getMessage());
            throw new RuntimeException("Property Service is currently unavailable", ex);
        } catch (Exception ex) {
            logger.error("Error while calling Property Service: {}", ex.getMessage());
            throw new RuntimeException("Error while calling Property Service", ex);
        }
    }

    public Property propertyServiceFallback(int propertyId, Throwable throwable) {
        // Fallback response when Property Service is down or unreachable
        logger.warn("Fallback response for Property Service: {}", throwable.getMessage());
        return new Property(propertyId, "Property Service is currently unavailable", "", "", 0, 0, false);
    }

    // Circuit Breaker for Payment Service (similar implementation as above)
    @CircuitBreaker(name = "payment-service", fallbackMethod = "paymentServiceFallback")
    public Payment createPayment(Payment payment) {
        String url = "http://payment-service/pay";
        // Implement rest of the method for payment service
        return null; // Example placeholder
    }

    public Payment paymentServiceFallback(Payment payment, Throwable throwable) {
        // Fallback response when Payment Service is down or unreachable
        logger.warn("Fallback response for Payment Service: {}", throwable.getMessage());
        return new Payment(0, payment.getBookingId(), "Payment Service is currently unavailable");
    }
    
    @CircuitBreaker(name = "property-service", fallbackMethod = "propertyServiceFallback")
    public Booking saveBooking(Booking booking) {
        // Check availability of rooms
        Property property = restTemplate.getForObject("http://property-service/property/" + booking.getPropertyId(), Property.class);
        if (property != null && property.getAvailableRooms() >= booking.getNumRooms() && !property.isLockForBook()) {
            // Lock the property for booking
            property.setLockForBook(true);
            restTemplate.put("http://property-service/property", property);

            // Create booking record
            booking.setBookingStatus("Initiated");
            bookingRepository.save(booking);

            // Create payment record
            Payment payment = new Payment();
            payment.setBookingId(String.valueOf(booking.getId()));
            payment.setAmount(String.valueOf(property.getPrice() * booking.getNumRooms()));
            ResponseEntity<Payment> paymentResponse = restTemplate.postForEntity("http://payment-service/pay", payment, Payment.class);

            if (paymentResponse.getStatusCode() == HttpStatus.OK) {
                // Update booking status and property availability
                property.setLockForBook(false);
                property.setAvailableRooms(property.getAvailableRooms() - booking.getNumRooms());
                restTemplate.put("http://property-service/property", property);

                booking.setBookingStatus("Booked");
                bookingRepository.save(booking);
            } else {
                // Update booking status to Failed
                booking.setBookingStatus("Failed");
                bookingRepository.save(booking);

                // Unlock the property
                property.setLockForBook(false);
                restTemplate.put("http://property-service/property", property);
            }
        } else {
            throw new RuntimeException("Property not available for booking");
        }
        return booking;
    }

    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    public Booking getBookingById(int id) {
        return bookingRepository.findById(id).orElse(null);
    }

    public void deleteBooking(int id) {
        bookingRepository.deleteById(id);
    }

    public Booking updateBooking(Booking booking) {
        return bookingRepository.save(booking);
    }
}
