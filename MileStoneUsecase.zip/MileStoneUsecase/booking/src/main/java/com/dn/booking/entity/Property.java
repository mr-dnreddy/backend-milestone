package com.dn.booking.entity;

public class Property {
    private int id;
    private String title;
    private String location;
    private String type;
    private double price;
    private int availableRooms;
    private boolean lockForBook;
    
	public Property() {
		super();
	}

	public Property(int id, String title, String location, String type, double price, int availableRooms,
			boolean lockForBook) {
		super();
		this.id = id;
		this.title = title;
		this.location = location;
		this.type = type;
		this.price = price;
		this.availableRooms = availableRooms;
		this.lockForBook = lockForBook;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getAvailableRooms() {
		return availableRooms;
	}

	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}

	public boolean isLockForBook() {
		return lockForBook;
	}

	public void setLockForBook(boolean lockForBook) {
		this.lockForBook = lockForBook;
	}
	
	
    
}
