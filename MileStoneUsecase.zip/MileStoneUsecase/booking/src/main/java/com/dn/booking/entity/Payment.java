package com.dn.booking.entity;

public class Payment {
    private int id;
    private String bookingId;
    private String amount;
	
    public Payment() {
		super();
	}

	public Payment(int id, String bookingId, String amount) {
		super();
		this.id = id;
		this.bookingId = bookingId;
		this.amount = amount;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

    
}
