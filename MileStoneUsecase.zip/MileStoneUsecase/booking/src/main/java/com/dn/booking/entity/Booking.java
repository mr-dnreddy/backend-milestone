package com.dn.booking.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Booking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String bookingDescription;
    private String orderNumber; // Booking number like BK-01
    private int propertyId; // primary Key of the property table
    private int numRooms; // required number of rooms
    private String bookingStatus; // Booking status like “Initiated”, ”Booked”, ”Failed”
	
    public Booking() {
		super();
	}

	public Booking(int id, String bookingDescription, String orderNumber, int propertyId, int numRooms,
			String bookingStatus) {
		super();
		this.id = id;
		this.bookingDescription = bookingDescription;
		this.orderNumber = orderNumber;
		this.propertyId = propertyId;
		this.numRooms = numRooms;
		this.bookingStatus = bookingStatus;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBookingDescription() {
		return bookingDescription;
	}

	public void setBookingDescription(String bookingDescription) {
		this.bookingDescription = bookingDescription;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public int getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(int propertyId) {
		this.propertyId = propertyId;
	}

	public int getNumRooms() {
		return numRooms;
	}

	public void setNumRooms(int numRooms) {
		this.numRooms = numRooms;
	}

	public String getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	@Override
	public String toString() {
		return "Booking [id=" + id + ", bookingDescription=" + bookingDescription + ", orderNumber=" + orderNumber
				+ ", propertyId=" + propertyId + ", numRooms=" + numRooms + ", bookingStatus=" + bookingStatus + "]";
	}
    
    
    
}
