package com.dn.serviceregistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceRegisrtyApplicationTests {

	@Test
	void contextLoads() {
	}

}
