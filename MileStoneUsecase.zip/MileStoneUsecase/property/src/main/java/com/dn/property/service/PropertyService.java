package com.dn.property.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dn.property.entity.Property;
import com.dn.property.repository.PropertyRepository;

@Service
public class PropertyService {
    @Autowired
    private PropertyRepository propertyRepository;

    public Property saveProperty(Property property) {
        return propertyRepository.save(property);
    }

    public List<Property> getAllProperties() {
        return propertyRepository.findAll();
    }

    public Property getPropertyById(int id) {
        return propertyRepository.findById(id).orElse(null);
    }

    public List<Property> getPropertyByTitle(String title) {
        return propertyRepository.findByTitle(title);
    }

    public List<Property> getPropertyByLocation(String location) {
        return propertyRepository.findByLocation(location);
    }

    public List<Property> getPropertyByType(String type) {
        return propertyRepository.findByType(type);
    }

    public List<Property> getPropertyByPrice(double price) {
        return propertyRepository.findByPrice(price);
    }

    public void deleteProperty(int id) {
        propertyRepository.deleteById(id);
    }

    public Property updateProperty(Property property) {
        return propertyRepository.save(property);
    }
}
