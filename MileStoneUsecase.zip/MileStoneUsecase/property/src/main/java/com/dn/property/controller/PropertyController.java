package com.dn.property.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dn.property.entity.Property;
import com.dn.property.service.PropertyService;

@RestController
@RequestMapping("/property")
public class PropertyController {
    @Autowired
    private PropertyService propertyService;

    @PostMapping
    public Property saveProperty(@RequestBody Property property) {
        return propertyService.saveProperty(property);
    }

    @GetMapping
    public List<Property> getAllProperties() {
        return propertyService.getAllProperties();
    }

    @GetMapping("/{id}")
    public Property getPropertyById(@PathVariable int id) {
        return propertyService.getPropertyById(id);
    }

    @GetMapping("/title/{title}")
    public List<Property> getPropertyByTitle(@PathVariable String title) {
        return propertyService.getPropertyByTitle(title);
    }

    @GetMapping("/location/{location}")
    public List<Property> getPropertyByLocation(@PathVariable String location) {
        return propertyService.getPropertyByLocation(location);
    }

    @GetMapping("/type/{type}")
    public List<Property> getPropertyByType(@PathVariable String type) {
        return propertyService.getPropertyByType(type);
    }

    @GetMapping("/price/{price}")
    public List<Property> getPropertyByPrice(@PathVariable double price) {
        return propertyService.getPropertyByPrice(price);
    }

    @DeleteMapping("/{id}")
    public void deleteProperty(@PathVariable int id) {
        propertyService.deleteProperty(id);
    }

    @PutMapping
    public Property updateProperty(@RequestBody Property property) {
        return propertyService.updateProperty(property);
    }
}
