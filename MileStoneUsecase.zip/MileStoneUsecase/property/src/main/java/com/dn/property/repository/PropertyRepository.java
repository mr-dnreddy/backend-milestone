package com.dn.property.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dn.property.entity.Property;

public interface PropertyRepository extends JpaRepository<Property, Integer> {
    List<Property> findByTitle(String title);
    List<Property> findByLocation(String location);
    List<Property> findByType(String type);
    List<Property> findByPrice(double price);
}
